package teste;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args){
	
		System.out.println("Verificar palavra:");
		Scanner s = new Scanner(System.in);
		String a = new String();
		a = s.nextLine();
		
		String inversa = new String("");
		
		Pilha<Character> pilha = new Pilha<>();
		
		for (int i = 0; i < a.length(); i++){
			pilha.empilha(a.charAt(i));
		}
		while(!pilha.estaVazia()){
			inversa += pilha.desempilha();
			
			}
		if(a.equals(inversa)){
			System.out.println(a + " � um palindromo");
		} else{
			System.out.println(a + " n�o � um palindromo!");
		}
	}

}
